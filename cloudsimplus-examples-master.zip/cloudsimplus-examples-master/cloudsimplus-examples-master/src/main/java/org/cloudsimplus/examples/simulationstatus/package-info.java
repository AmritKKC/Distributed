/**
 * Examples showing how to control simulation execution by
 * pausing, resuming and stopping it.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudsimplus.examples.simulationstatus;
