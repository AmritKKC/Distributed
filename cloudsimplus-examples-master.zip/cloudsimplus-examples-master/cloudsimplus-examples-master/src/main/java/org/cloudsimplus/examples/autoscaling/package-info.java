/**
 * Examples showing how to enable horizontal and vertical
 * VM scaling using the {@link org.cloudsimplus.autoscaling.HorizontalVmScaling}
 * and {@link org.cloudsimplus.autoscaling.VerticalVmScaling}.
 *
 * @author Manoel Campos da Silva Filho
 */
package org.cloudsimplus.examples.autoscaling;
